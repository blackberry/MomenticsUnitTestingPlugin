COVERAGE_OUTPUT_DIR=cover
RAW_COVERAGE_FILE=$COVERAGE_OUTPUT_DIR/coverage.info
EXTRACTED_COVERAGE_FILE=$COVERAGE_OUTPUT_DIR/extracted_coverage.info
SPLITTER="--------------------------------------------------------------------------------------"
APP_NAME=sample
APP_SRC_FOLDER=.

title(){
  	echo "$SPLITTER"
	echo "$1"
	echo "$SPLITTER"
}

toolCheck(){
	if ! which $1 >/dev/null; then
    	echo "$1 is not installed"
    	exit 1;
	fi;
}

# Check that the needed tools are installed
toolCheck lcov
toolCheck genhtml

title "Building tests"
sh build.sh

# Reset the counters for code coverage 
lcov --directory . --zerocounters

title "Running the tests"
./Debug-Linux/UnitTests.exe --gtest_shuffle --gtest_output=xml --gtest_output=xml:reports/testresult.xml;

title "Gathering code coverage data and converting it to HTML"
mkdir -p $COVERAGE_OUTPUT_DIR

# Gathering coverage
lcov --directory Debug-Linux --capture --output-file $RAW_COVERAGE_FILE

# Only show code coverage for you app.
lcov --extract $RAW_COVERAGE_FILE "*$APP_NAME*" --output-file $EXTRACTED_COVERAGE_FILE

# Creating the html docs
genhtml $EXTRACTED_COVERAGE_FILE --legend --output-directory $COVERAGE_OUTPUT_DIR

# Create gcovr report. The changes the gcovr output into Cobertura output for the jenkins build server.
python ./gcovr --root=$APP_SOURCE_FOLDER --xml --output=cover/gcovr.xml

title Done
