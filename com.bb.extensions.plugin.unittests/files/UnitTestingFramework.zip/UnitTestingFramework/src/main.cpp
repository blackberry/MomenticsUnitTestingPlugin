/*
�* Copyright (C) 2012 Research In Motion Limited. Proprietary and confidential.
�*
�* main.cpp
�*/

#include <gtest/gtest.h>

#include <QCoreApplication>

/**
�* The main entry point for running the unit tests.
�*/
int main(int argc, char** argv) {
	QCoreApplication app(argc, argv);

	testing::InitGoogleTest(&argc, argv);
	return RUN_ALL_TESTS();
}

